/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TravelersPointBusServices;

import javax.swing.JFrame;

/**
 *
 * @author Anish Kumar Singh
 */
class JOptioPane {

    static int showConfirmDialog(JFrame frame, String confirm_if_you_want_to_exit, int YES_NO_OPTION) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
